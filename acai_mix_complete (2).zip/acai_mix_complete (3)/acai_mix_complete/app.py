from flask import Flask, render_template, request, redirect, session, flash, url_for
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "supersecretkey"

# -------------------- Banco de dados --------------------
DB_NAME = 'acai.db'

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Cria tabelas se não existirem, incluindo coluna de descrição e imagem"""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Usuários
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            senha TEXT NOT NULL,
            cpf TEXT,
            endereco TEXT
        )
    ''')

    # Estoque
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS estoque (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            descricao TEXT,
            quantidade INTEGER NOT NULL,
            preco REAL NOT NULL,
            imagem TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# -------------------- Rotas --------------------
@app.route('/')
def index():
    return redirect(url_for('dashboard'))

# -------------------- Cadastro --------------------
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        cpf = request.form['cpf']
        endereco = request.form['endereco']

        hashed_senha = generate_password_hash(senha)

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO usuarios (email, senha, cpf, endereco) VALUES (?, ?, ?, ?)",
                           (email, hashed_senha, cpf, endereco))
            conn.commit()
            flash("Cadastro realizado com sucesso!", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Email já cadastrado!", "danger")
        finally:
            conn.close()
    return render_template('signup.html')

# -------------------- Login --------------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']

        # Login admin
        if email == 'admin@acai' and senha == 'admin123':
            session['admin'] = True
            return redirect(url_for('admin'))

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE email=?", (email,))
        user = cursor.fetchone()
        conn.close()

        if user and check_password_hash(user['senha'], senha):
            session['user'] = user['id']
            return redirect(url_for('dashboard'))
        else:
            flash("Email ou senha incorretos", "danger")
    return render_template('login.html')

# -------------------- Dashboard --------------------
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

# -------------------- Produtos --------------------
@app.route('/produtos')
def produtos():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM estoque")
    itens = cursor.fetchall()
    conn.close()
    return render_template('produtos.html', itens=itens)

@app.route("/unidades")
def unidades():
    return render_template("unidades.html")

# -------------------- Carrinho --------------------
@app.route('/add_to_cart/<int:item_id>')
def add_to_cart(item_id):
    if 'user' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM estoque WHERE id=?", (item_id,))
    item = cursor.fetchone()
    conn.close()

    if not item:
        flash("Produto não encontrado!", "danger")
        return redirect(url_for('produtos'))

    if 'cart' not in session:
        session['cart'] = {}

    cart = session['cart']
    current_qty = cart.get(str(item_id), 0)

    if current_qty >= item['quantidade']:
        flash("Não há estoque suficiente!", "danger")
    else:
        cart[str(item_id)] = current_qty + 1
        flash("Item adicionado ao carrinho!", "success")

    session['cart'] = cart
    return redirect(url_for('produtos'))

@app.route('/cart')
def view_cart():
    if 'user' not in session:
        return redirect(url_for('login'))

    cart = session.get('cart', {})
    conn = get_db_connection()
    cursor = conn.cursor()

    items_in_cart = []
    total = 0
    for item_id, quantidade in cart.items():
        cursor.execute("SELECT * FROM estoque WHERE id=?", (item_id,))
        item = cursor.fetchone()
        if item:
            subtotal = item['preco'] * quantidade
            total += subtotal
            items_in_cart.append({
                'id': item['id'],
                'nome': item['nome'],
                'quantidade': quantidade,
                'preco': item['preco'],
                'subtotal': subtotal
            })
    conn.close()
    return render_template('cart.html', items=items_in_cart, total=total)

@app.route('/remove_from_cart/<int:item_id>')
def remove_from_cart(item_id):
    if 'user' not in session:
        return redirect(url_for('login'))
    cart = session.get('cart', {})
    cart.pop(str(item_id), None)
    session['cart'] = cart
    return redirect(url_for('view_cart'))

@app.route('/checkout')
def checkout():
    if 'user' not in session:
        return redirect(url_for('login'))

    cart = session.get('cart', {})
    if not cart:
        flash("Seu carrinho está vazio!", "danger")
        return redirect(url_for('produtos'))

    conn = get_db_connection()
    cursor = conn.cursor()

    for item_id, quantidade in cart.items():
        cursor.execute("SELECT quantidade FROM estoque WHERE id=?", (item_id,))
        estoque_atual = cursor.fetchone()
        if estoque_atual:
            novo_estoque = estoque_atual['quantidade'] - quantidade
            if novo_estoque < 0:
                novo_estoque = 0
            cursor.execute("UPDATE estoque SET quantidade=? WHERE id=?", (novo_estoque, item_id))
    conn.commit()
    conn.close()

    session.pop('cart', None)
    flash("Compra finalizada com sucesso!", "success")
    return redirect(url_for('dashboard'))

# -------------------- Admin --------------------
@app.route('/admin')
def admin():
    if 'admin' not in session:
        flash("Acesso negado!", "danger")
        return redirect(url_for('login'))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM estoque")
    itens = cursor.fetchall()
    conn.close()
    return render_template('admin.html', itens=itens)

@app.route('/add_item', methods=['POST'])
def add_item():
    if 'admin' not in session:
        return redirect(url_for('login'))

    nome = request.form['nome']
    descricao = request.form['descricao']
    quantidade = int(request.form['quantidade'])
    preco = float(request.form['preco'])
    imagem_path = request.form.get('imagem')  # <- apenas URL agora

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO estoque (nome, descricao, quantidade, preco, imagem) VALUES (?, ?, ?, ?, ?)",
        (nome, descricao, quantidade, preco, imagem_path)
    )
    conn.commit()
    conn.close()
    flash("Produto adicionado com sucesso!", "success")
    return redirect(url_for('admin'))

@app.route('/edit_item/<int:id>', methods=['POST'])
def edit_item(id):
    if 'admin' not in session:
        return redirect(url_for('login'))

    nome = request.form['nome']
    descricao = request.form['descricao']
    quantidade = int(request.form['quantidade'])
    preco = float(request.form['preco'])
    imagem = request.form['imagem']

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE estoque SET nome=?, descricao=?, quantidade=?, preco=?, imagem=? WHERE id=?",
        (nome, descricao, quantidade, preco, imagem, id)
    )
    conn.commit()
    conn.close()
    flash("Produto editado com sucesso!", "success")
    return redirect(url_for('admin'))

@app.route('/delete_item/<int:id>')
def delete_item(id):
    if 'admin' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM estoque WHERE id=?", (id,))
    conn.commit()
    conn.close()
    flash("Produto removido com sucesso!", "success")
    return redirect(url_for('admin'))

# -------------------- Logout --------------------
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# -------------------- Rodar app --------------------
if __name__ == '__main__':
    app.run(debug=True)

@app.route("/unidades")
def unidades():
    return render_template("unidades.html")
