// --------------------
// Controle do Tema
// --------------------
const botao = document.getElementById('modo-btn');
if (botao) {
  const temaSalvo = localStorage.getItem('tema');

  if (temaSalvo === 'escuro') {
    document.body.classList.add('dark-mode');
    botao.textContent = 'Modo Claro';
  } else {
    botao.textContent = 'Modo Escuro';
  }

  botao.addEventListener('click', function (event) {
    event.preventDefault();
    document.body.classList.toggle('dark-mode');

    if (document.body.classList.contains('dark-mode')) {
      localStorage.setItem('tema', 'escuro');
      botao.textContent = 'Modo Claro';
    } else {
      localStorage.setItem('tema', 'claro');
      botao.textContent = 'Modo Escuro';
    }
  });
}

// --------------------
// Controle do Menu
// --------------------
const menuToggle = document.getElementById("menu-toggle");
const menu = document.getElementById("menu");

if (menuToggle && menu) {
  menuToggle.addEventListener("click", function(event) {
    event.stopPropagation();
    menu.classList.toggle("show");
  });

  document.addEventListener("click", function(event) {
    if (menu.classList.contains("show") && !menu.contains(event.target) && event.target !== menuToggle) {
      menu.classList.remove("show");
    }
  });

  function atualizarMenu() {
    if (window.innerWidth > 768) {
      menu.classList.remove("show"); // garante que o menu apareça no desktop
    }
  }

  window.addEventListener('load', atualizarMenu);
  window.addEventListener('resize', atualizarMenu);
}
